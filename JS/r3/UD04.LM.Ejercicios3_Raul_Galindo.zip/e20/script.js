function suma(limite) {
    let suma = 0;
    for (let i = 1; i <= limite; i++) {
        suma += i;
    }
    return suma;
}