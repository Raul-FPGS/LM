function castigo(cadena, veces) {
    for (let i = 0; i < veces; i++) {
        console.log(cadena);
    }
}