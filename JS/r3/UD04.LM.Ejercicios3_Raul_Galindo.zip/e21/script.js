function producto(limite) {
    let producto = 1;
    for (let i = 1; i <= limite; i++) {
        producto *= i;
    }
    return producto
}