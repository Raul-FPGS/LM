function tabla(numero) {
    for (let i = 0; i <= 10; i++) {
        console.log(numero + " x " + i + " = " + (numero * i));
    }
}