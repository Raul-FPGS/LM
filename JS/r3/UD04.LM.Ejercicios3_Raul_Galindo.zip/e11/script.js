function par_impar(numero) {
    let resultado = false;
    if (numero % 2 == 0) {
        resultado = true;
    }
    return resultado;
}