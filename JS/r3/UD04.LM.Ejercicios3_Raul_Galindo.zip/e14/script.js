function potencia(base, exponente) {
    return base ** exponente;
}