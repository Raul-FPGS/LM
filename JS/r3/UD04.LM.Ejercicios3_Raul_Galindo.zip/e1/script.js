function parImpar(numero) {
    resultado = "Impar";
    if (numero % 2 == 0) {
        resultado = "Par";
    }
    return resultado;
}

console.log(parImpar(5))