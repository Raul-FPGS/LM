function rango(inicio, final) {
    for (let i = inicio; i <= final; i++) {
        console.log(i);
    }
}