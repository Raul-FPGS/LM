function par_impar(numero) {
    let resultado = 0;
    if (numero % 2 == 0) {
        resultado = 1;
    }
    return resultado;
}