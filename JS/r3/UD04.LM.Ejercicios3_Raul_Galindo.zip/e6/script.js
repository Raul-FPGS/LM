function linea(caracter, veces) {
    for (let i = 0; i < veces; i++) {
        console.log(caracter);
    }
}

linea("*", 5)