/* Añade dos alertas a la pagina web */
alert("Hola Mundo!");
alert("Soy el primer script");
