/* Lanza una alerta */
alert("Esta alerta esta desde otro archivo JS")

// Lanza otra alerta
alert("Esta alerta va despues de la anterior")