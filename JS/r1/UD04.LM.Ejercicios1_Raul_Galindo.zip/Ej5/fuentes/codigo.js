alert("Esta alerta esta desde otro archivo JS")
alert("Esta alerta va despues de la anterior")