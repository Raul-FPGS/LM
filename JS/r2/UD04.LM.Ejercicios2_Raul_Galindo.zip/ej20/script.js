let tabla = 5
for (let i = 1; i <= 10; i++) {
    console.log(tabla + " x " + i + " = " + (i * tabla));
}