let longitud = parseInt(prompt("Introduce la longitud"));

let linea = "";

for (let i = 0; i < longitud; i++) {
    linea += "*";
}
alert(linea);