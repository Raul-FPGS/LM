let suma = 0;
let limite = parseInt(prompt("Introduce un limite"));
for (let i = 1; i <= limite; i++) {
    suma += i;
}
alert("La suma es: " + suma);