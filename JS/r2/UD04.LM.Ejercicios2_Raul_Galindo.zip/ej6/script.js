mayor = confirm("Eres mayor de edad?");

if (mayor) {
    alert("Eres mayor de edad");
} else {
    alert("No eres mayor de edad");
}