let numero = parseInt(prompt("Cuantas veces se imprimira"));
let texto = "Tabulare ben mis programas";
for (let i = 0; i < numero; i++) {
    document.write(texto + "<br>");
}