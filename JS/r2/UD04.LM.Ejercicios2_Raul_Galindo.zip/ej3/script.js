let texto = prompt("Introduce un texto");

if (texto.indexOf(" ") == -1) {
    alert("Tiene espacios");
} else {
    alert("No tiene espacios");
}