let limite = parseInt(prompt("Introduce un limite"));
for (let i = 1; i <= limite; i++) {
    console.log(i);
}