let numeroAleatorio = Math.random();

if (numeroAleatorio >= 0.5) {
    alert("Cara");
} else {
    alert("Cruz");
}