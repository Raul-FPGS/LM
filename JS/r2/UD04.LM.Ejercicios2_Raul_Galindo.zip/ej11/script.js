let dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"];

for (let i = 0; i < dias.length; i++) {
    document.write(dias[i] + "<br>");
}