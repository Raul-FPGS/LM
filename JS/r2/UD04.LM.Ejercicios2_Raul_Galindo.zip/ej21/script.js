let tabla = parseInt(prompt("Introduce un numero"));
for (let i = 1; i <= 10; i++) {
    console.log(tabla + " x " + i + " = " + (i * tabla));
}