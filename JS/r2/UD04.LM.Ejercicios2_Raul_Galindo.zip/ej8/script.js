let edad = parseInt(prompt("Introduce tu edad"));
let saldo = parseFloat(prompt("Introduce tu saldo"));

if (edad >= 18 && saldo >= 100) {
    alert("Puede seguir jugando");
}