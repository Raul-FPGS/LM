while (true) {
    numero = parseInt(prompt("Introduce un numero"));
    if (numero > 0) {
        break;
    }
}
