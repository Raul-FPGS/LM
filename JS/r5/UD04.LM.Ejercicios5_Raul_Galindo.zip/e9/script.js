let cadena = prompt("Introduce algo");
let cadenaMayus = cadena.toUpperCase();
let cadenaMinus = cadena.toLowerCase();
document.write(cadenaMayus);
document.write(cadenaMinus);