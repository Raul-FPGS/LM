let dni = "12345678A";
let dniNumeros = dni.substring(0, 8);
document.write(dniNumeros);