let pruebas = "abcdefghijklmn";
console.log(pruebas.indexOf("f"));
console.log(pruebas[11]);