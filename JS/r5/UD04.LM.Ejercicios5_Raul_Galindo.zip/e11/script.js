let pruebas = "Hola y adios";
console.log(pruebas.indexOf("a"));
console.log(pruebas.lastIndexOf("a"));