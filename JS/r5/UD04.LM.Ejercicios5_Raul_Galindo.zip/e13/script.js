let dni = "12345678A";
let dniNumeros = dni[8];
document.write(dniNumeros);