let nombre = " Don Quijote";
console.log(nombre.length);