let nombre = " Don Quijote";
let nombreCompleto = nombre + "de La Mancha";

document.write(nombreCompleto)