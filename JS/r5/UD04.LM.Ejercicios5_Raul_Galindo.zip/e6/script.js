let nombre = prompt("Introduce tu nombre");
let apellidos = prompt("Introduce tus apellidos");
let nombreCompleto = apellidos + ", " + nombre;
document.write(nombreCompleto);