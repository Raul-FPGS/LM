let dni = "12345678A";
let dniNumeros = dni.substring(dni.length - 4);
document.write(dniNumeros);