let dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"];

console.log(dias.join(", "));
console.log(dias.reverse());
console.log(dias.sort());
console.log(dias.indexOf("Lunes"));