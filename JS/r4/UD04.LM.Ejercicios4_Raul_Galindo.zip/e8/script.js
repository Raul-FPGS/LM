var numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

function suma(valor) {
    for (let i = 0; i < numeros.length; i++) {
        numeros[i] += valor;
    }
}