let dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"];

console.log(dias.length + " " + dias);
console.log(dias.pop(0));
console.log(dias.length + " " + dias);
console.log(dias.push("Sunday"));
console.log(dias.length + " " + dias);