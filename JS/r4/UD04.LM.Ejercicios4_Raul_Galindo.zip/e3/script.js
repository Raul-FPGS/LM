let valores = [true, 5, false, "hola", "adios", 2];

if (valores[3].length > valores[4].length) {
    console.log("La variable 3 tiene mas caracteres");
} else {
    console.log("La variable 4 tiene mas caracteres");
}

console.log(valores[1] + valores[5]);
console.log(valores[1] * valores[5]);
console.log(valores[1] / valores[5]);
console.log(valores[1] - valores[5]);
console.log(valores[1] % valores[5]);