let dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"];
console.log(dias[0]);
console.log(dias[dias.length - 1]);
